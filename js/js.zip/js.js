window.onload = function (ev){
	setTimeout(function (){
		$('.loading').hide();
		$('.p1 .main').fadeIn()
	}, 1500);
}
$(function (){
	init();
	fenxiang('寻找最美凉茶摊', '每年夏季，浙江街头的爱心凉茶摊如期而至，茶香泗溢，为过路人送去一份清凉！', '斟满一杯凉茶 传递一份爱心', '', 'https://o.cztvcloud.com/181/4838001/images/fenxiang.jpg')
	//必须在微信Weixin JSAPI的WeixinJSBridgeReady才能生效
	//video{}
	//判断是横屏还是竖屏的方法:
	$(window).bind('orientationchange', function (e){//用户变化屏幕方向时调用
		orient();
	});
	//必须在微信Weixin JSAPI的WeixinJSBridgeReady才能生效
	document.addEventListener("WeixinJSBridgeReady", function (){
		document.getElementById('video').load();
		document.getElementById('musics').load();
		document.getElementById('musics').play();
	}, false);
	document.getElementById('musics').play();
	//music controler
	play_now = true;
	music_now = true;
	playused = false;
	change = false
	index = 0
	$('.music_play').click(function (){
		if (play_now) {
			$('.music_play').removeClass('music_pause');
			$('.music_play').addClass('music_pause');
			play_now = false;
			playused = false;
			$('.bgMusic')[0].pause();
			$('.music').attr('src', 'http://o.cztvcloud.com/181/4838001/images/music_off.png')
		} else {
			$('.music_play').removeClass('music_pause');
			play_now = true;
			playused = false;
			$('.bgMusic')[0].play();
			$('.music').attr('src', 'http://o.cztvcloud.com/181/4838001/images/music.png')
		}
	});
	var video = document.getElementById('video')
	video.addEventListener('pause', function (){
		console.log('video paused');
	})
	//视频关闭
	$('.back').click(function (){
		$('.videobox').hide();
		video.pause()
		musicreturn()
	})
	//播放事件
	// video.addEventListener('play', videoplay)
	function videoplay(index){
		if (times < 5) {
			$('#video').attr("src", videolists[index - 1]);
			$('.vtext').attr("src", ".http://o.cztvcloud.com/181/4838001/images/videotext" + index + ".png")
			$('.videobox').show()
			video.play()
			if (play_now) {
				$('.music_play').removeClass('music_pause');
				$('.music_play').addClass('music_pause');
				playused = true;
				$('.bgMusic')[0].pause();
			}
			video.addEventListener('pause', musicreturn)
			video.addEventListener('ended', musicreturn)
		}
	}
	function musicreturn(){
		if (playused) {
			$('.music_play').removeClass('music_pause');
			play_now = true;
			$('.bgMusic')[0].play();
		}
	}
	var canvas_scale = window.innerWidth / 750;
	// var canvas_scale = 1
	// alert(document.documentElement.clientWidth);
	var rem = window.innerWidth / 750 * 100;
	var canvasWidth = 7.5 * rem;
	var canvasHeight = 111.40 * rem;
	var endline = Math.floor(111.40 * rem - window.innerHeight)
	// console.log(endline);
	var canvas = document.getElementById("canvas");
	canvas.width = window.innerWidth
	canvas.height = window.innerHeight;
	//create stage
	var stage = new createjs.Stage('canvas');
	//大背景
	var container = new createjs.Container();
	stage.addChild(container);
	var position = [0, 14.48, 28.96, 43.44, 57.92, 72.4, 86.88, 101.36]
	for (var i = 0; i < 8; i++) {
		setTimeout((function (i){// Holy Shit Closures
			var clicked = false
			var image = new Image()
			image.crossOrigin = 'anonymous';
			image.src = "http://o.cztvcloud.com/181/4838001/images/background_0" + parseInt(i + 1) + ".jpg";
			image.onload = function (ev){
				var bitmap = new createjs.Bitmap(event.target);
				bitmap.name = "bitmap" + i
				bitmap.x = 0 * rem;
				bitmap.y = position[i] * rem;
				// console.log('i' + position[i] + ' : ' + 14.48 * i);
				bitmap.scaleX = canvas_scale;
				bitmap.scaleY = canvas_scale;
				container.addChild(bitmap);
				stage.update();
			};
		}), 0, i);
	}
	createjs.Touch.enable(stage);
	stage.enableMouseOver()
	createjs.Ticker.setFPS(60);
	createjs.Ticker.addEventListener("tick", stage)
	createjs.Ticker.addEventListener("tick", scroll)
	var y = -1;
	var tempy = 0;
	movenow = false;
	var times = 0
	function wetherScroll(){
		var canvas = document.querySelector("#canvas");
		//信号量
		stage.y = -4 * rem;
		var y = stage.y;
		var startX, startY, dx, dy, endup, enddw;
		endup = true, enddw = false
		canvas.addEventListener("touchstart", function (event){
			times = 0
			event.preventDefault();
			var thefinger = event.touches[0];
			startX = thefinger.clientX;
			startY = thefinger.clientY;
		}, true);
		canvas.addEventListener("touchmove", function (event){
			times++
			movenow = true;
			stage.mouseEnabled = false
			event.preventDefault();
			var thefinger = event.touches[0];
			dy = thefinger.clientY - startY;
			var distance = (y + dy)//负数
			if (dy > 0) {//手指往下滑
				if ((y + dy) >= 0) {//到底了
					y = 0
					stage.y = 0;
					tempy = stage.y
					stage.update();
				} else {
					stage.y = y + dy
					tempy = stage.y
					stage.update();
				}
			} else {//手指往上滑
				if (-(y + dy) > endline) {	//到底了
					stage.y = -endline;
					tempy = stage.y
					stage.update();
				} else {
					stage.y = y + dy;
					tempy = stage.y
					stage.update();
				}
			}
		}, true);
		//触摸结束
		canvas.addEventListener("touchend", function (event){
			movenow = false;
			stage.mouseEnabled = true
			event.preventDefault();
			if (dy >= 0) {//手指往下滑
				if ((y + dy) >= 0) {//到底了
					y = 0
				} else {
					y += dy;
				}
			} else {//手指往上滑
				if (-(y + dy) >= endline) {	//到底了
					y = -endline
				} else {
					y += dy;
				}
			}
			stage.update();
			console.log(times);
		}, true);
	}
	//part1
	// stage.enableMouseOver()
	var part1 = new createjs.Container();
	stage.addChild(part1);
	for (var i = 0; i < 6; i++) {
		setTimeout((function (i){// Holy Shit Closures
			var clicked = false
			var image = new Image()
			image.crossOrigin = 'anonymous';
			image.src = "http://o.cztvcloud.com/181/4838001/images/yc" + parseInt(i + 1) + ".png";
			image.onload = function (ev){
				var bitmap = new createjs.Bitmap(event.target);
				bitmap.name = "bitmap" + i
				bitmap.x = 1.25 * rem * i;
				bitmap.y = 1.52 * rem;
				bitmap.snapToPixel = false;
				bitmap.cursor = 'pointer';
				bitmap.scaleX = canvas_scale;
				bitmap.scaleY = canvas_scale;
				part1.addChild(bitmap);
				stage.update();
				bitmap.addEventListener('click', function (){
					clicked = true;
					var bitmapname = bitmap.name;
					for (var nameIndex = 0; nameIndex < 6; nameIndex++) {
						createjs.Tween.get(part1.getChildByName("bitmap" + nameIndex)).to({
							alpha: 0,
							x: 3.80 * rem,
							y: 4 * rem
						}, 500)
					}
					// 茶壶动画
					animation.gotoAndPlay("start");
					//文字动画
					createjs.Tween.get(part1_text.getChildByName("t0")).wait(1000).to({
						alpha: 1,
						x: 0,
						y: 6.26 * rem
					}, 600, createjs.Ease.quadOut);
					createjs.Tween.get(part1_text.getChildByName("t1")).wait(1400).to({
						alpha: 1,
						x: 0,
						y: 6.26 * rem
					}, 600, createjs.Ease.quadOut);
					createjs.Tween.get(part1_text.getChildByName("t2")).wait(1800).to({
						alpha: 1,
						x: 0,
						y: 6.26 * rem
					}, 600, createjs.Ease.quadOut);
					createjs.Tween.get(part1_text.getChildByName("t3")).wait(2200).to({
						alpha: 1,
						x: 0,
						y: 6.26 * rem
					}, 600, createjs.Ease.quadOut);
					//地图动画
					createjs.Tween.get(map.getChildByName("mapbg")).wait(2500).to({
						alpha: 1,
					}, 500, createjs.Ease.quadOut);
					createjs.Tween.get(map.getChildByName("people")).wait(3000).to({
						alpha: 1,
					}, 600, createjs.Ease.quadOut);
					createjs.Tween.get(map.getChildByName("mapicon")).wait(3500).to({
						alpha: 1,
						y: 9.26 * rem
					}, 600, createjs.Ease.quadOut);
					stage.removeChild(part1_tea_hand);
					stage.update();
					//调用updata更新
					createjs.Tween.get(stage).to({
						y: -4 * rem,
					}, 4500, createjs.Ease.quadOut).call(function (){
						console.log('over')
						wetherScroll()
					})
					stage.update();
				})
			};
		}), 0, i);
	}
	//part1-teapot
	var datainstance = {//创建一个动画实例
		"images": ["http://o.cztvcloud.com/181/4838001/images/test.png"],
		"frames": {
			"width": 270,            //每个图的高度为292，宽度为165，一共有64张图
			"height": 214,
			"count": 18
		},
		"animations": {
			start: {
				frames: [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 15, 16, 17],
				next: "",
				speed: 0.25
			},
			stop: {
				frames: [17],
				next: "stop",
				speed: 1
			},
			// "start": [0, 0, 'run', 0.1],
			// "run": [0, 18],                  //0帧到25帧是跳
		}
	}
	var spriteSheet = new createjs.SpriteSheet(datainstance);
	var animation = new createjs.Sprite(spriteSheet);
	animation.gotoAndStop("stop");
	/*
	*part2
	*/
	var part2 = new createjs.Container();
	part2.x = 2.5 * rem;
	part2.y = 4 * rem;
	part2.scaleX = canvas_scale
	part2.scaleY = canvas_scale
	stage.addChild(part2);
	part2.addChild(animation)
	//part1-tea-hand
	var part1_tea_hand = new createjs.Container();
	stage.addChild(part1_tea_hand);
	var image = new Image()
	image.crossOrigin = 'anonymous';
	image.src = "http://o.cztvcloud.com/181/4838001/images/hand.png";
	image.onload = function (ev){
		var w = image.width;
		var scale = canvas_scale
		var bitmap = new createjs.Bitmap(image.src);
		bitmap.name = "hand"
		bitmap.x = 3.3 * rem;
		bitmap.y = 2.2 * rem;
		bitmap.scaleX = canvas_scale;
		bitmap.scaleY = canvas_scale;
		part1_tea_hand.addChild(bitmap);
		createjs.Tween.get(part1_tea_hand.getChildByName("hand"), {loop: true}).to({
			alpha: 0.2,
		}, 300).to({
			alpha: 1,
		}, 300)
		stage.update();
		bitmap.addEventListener('touchstart', function (){
			animation.gotoAndPlay("start");
			stage.update(); 				//调用updata更新
		})
	};
	var part1_text = new createjs.Container();
	stage.addChild(part1_text);
	for (var i = 0; i < 4; i++) {
		setTimeout((function (i){// Holy Shit Closures
			var clicked = false
			var image = new Image()
			image.crossOrigin = 'anonymous';
			image.src = "http://o.cztvcloud.com/181/4838001/images/t" + parseInt(i + 1) + ".png";
			image.onload = function (ev){
				var bitmap = new createjs.Bitmap(image.src);
				bitmap.name = "t" + i;
				bitmap.alpha = 0;
				bitmap.x = 0;
				bitmap.y = 7 * rem;
				bitmap.scaleX = canvas_scale;
				bitmap.scaleY = canvas_scale;
				part1_text.addChild(bitmap);
				stage.update();
			};
		}), 0, i);
	}
	//地图
	var map = new createjs.Container();
	stage.addChild(map);
	{
		var mapbg = new Image()
		mapbg.crossOrigin = 'anonymous';
		mapbg.src = "http://o.cztvcloud.com/181/4838001/images/mapbg.png"
		mapbg.onload = function (ev){
			var mapbp = new createjs.Bitmap(mapbg.src);
			mapbp.name = 'mapbg';
			mapbp.alpha = 0;
			mapbp.x = 0;
			mapbp.y = 9.27 * rem;
			mapbp.scaleX = canvas_scale;
			mapbp.scaleY = canvas_scale;
			map.addChild(mapbp);
			stage.update();
		};
		var people = new Image()
		people.crossOrigin = 'anonymous';
		people.src = "http://o.cztvcloud.com/181/4838001/images/people.png"
		people.onload = function (ev){
			var peoplebp = new createjs.Bitmap(people.src);
			peoplebp.name = 'people';
			peoplebp.alpha = 0;
			peoplebp.x = 0;
			peoplebp.y = 9.27 * rem;
			peoplebp.scaleX = canvas_scale;
			peoplebp.scaleY = canvas_scale;
			map.addChild(peoplebp);
			stage.update();
		};
		var mapicon = new Image()
		mapicon.crossOrigin = 'anonymous';
		mapicon.src = "http://o.cztvcloud.com/181/4838001/images/mapicon.png"
		mapicon.onload = function (ev){
			var mapiconbp = new createjs.Bitmap(mapicon.src);
			mapiconbp.name = "mapicon";
			mapiconbp.alpha = 0;
			mapiconbp.x = 0;
			mapiconbp.y = 9 * rem;
			mapiconbp.scaleX = canvas_scale;
			mapiconbp.scaleY = canvas_scale;
			map.addChild(mapiconbp);
			stage.update();
		};
	}
	var mrgu = new createjs.Container();
	stage.addChild(mrgu);
	var mrgutext = new Image()
	mrgutext.crossOrigin = 'anonymous';
	mrgutext.src = "http://o.cztvcloud.com/181/4838001/images/text2.png";
	mrgutext.onload = function (ev){
		var mrgbp = new createjs.Bitmap(mrgutext.src);
		mrgbp.name = "mrgutext";
		mrgbp.alpha = 0;
		mrgbp.x = 4 * rem;
		mrgbp.y = 14.87 * rem;
		mrgbp.scaleX = canvas_scale;
		mrgbp.scaleY = canvas_scale;
		mrgu.addChild(mrgbp);
		stage.update();
	};
	var chalu = new Image()
	chalu.crossOrigin = 'anonymous';
	chalu.src = "http://o.cztvcloud.com/181/4838001/images/chalu.png";
	chalu.onload = function (ev){
		var chalubp = new createjs.Bitmap(chalu.src);
		chalubp.name = "guchalu";
		chalubp.alpha = 0;
		chalubp.x = -1 * rem;
		chalubp.y = 23.23 * rem;
		chalubp.scaleX = canvas_scale;
		chalubp.scaleY = canvas_scale;
		chalubp.addEventListener('click', function (){
			console.log('茶壶 video1')
			videoplay(1)
		}, false)
		mrgu.addChild(chalubp);
		stage.update();
	};
	var chalutext = new Image()
	chalutext.crossOrigin = 'anonymous';
	chalutext.src = "http://o.cztvcloud.com/181/4838001/images/text3.png";
	chalutext.onload = function (ev){
		var chalutextbp = new createjs.Bitmap(chalutext.src);
		chalutextbp.name = "chalutextbp";
		chalutextbp.alpha = 0;
		chalutextbp.x = -1 * rem;
		chalutextbp.y = 28.22 * rem;
		chalutextbp.scaleX = canvas_scale;
		chalutextbp.scaleY = canvas_scale;
		mrgu.addChild(chalutextbp);
		stage.update();
	};
	//shaoshuiSheet
	var shaoshuiSheet = {
		"images": ["http://o.cztvcloud.com/181/4838001/images/shaoshui.png"],
		"frames": {
			"width": 486,
			"height": 494,
			"count": 6
		},
		"animations": {
			start: {
				frames: [0, 1, 2, 3, 4, 5],
				next: 'start',
				speed: 0.1,
			},
		}
	}
	var shaoshui = new createjs.SpriteSheet(shaoshuiSheet);
	var am_shaoshui = new createjs.Sprite(shaoshui, 'start');
	am_shaoshui.x = -0.3 * rem;
	am_shaoshui.y = 52 * rem;
	am_shaoshui.scaleX = canvas_scale;
	am_shaoshui.scaleY = canvas_scale;
	part2.addChild(am_shaoshui)
	stage.update()
	//daye
	var dayeSheet = {
		"images": ["http://o.cztvcloud.com/181/4838001/images/daye.png"],
		"frames": {
			"width": 462,
			"height": 451,
			"count": 23
		},
		"animations": {
			"start": [0, 22, 'start', 0.2]
		}
	}
	var dayeSheetSprite = new createjs.SpriteSheet(dayeSheet);
	var am_daye = new createjs.Sprite(dayeSheetSprite, 'start');
	am_daye.x = 3.7 * rem;
	am_daye.y = 29 * rem;
	am_daye.scaleX = canvas_scale;
	am_daye.scaleY = canvas_scale;
	am_daye.gotoAndPlay("start");
	part2.addChild(am_daye);
	stage.addChild(part2)
	stage.update()
	//part3
	var part3 = new createjs.Container();
	stage.addChild(part3);
	var text4 = new Image()
	text4.crossOrigin = 'anonymous';
	text4.src = "http://o.cztvcloud.com/181/4838001/images/text4.png";
	text4.onload = function (ev){
		var text4bp = new createjs.Bitmap(text4.src);
		text4bp.name = "text4bp";
		text4bp.alpha = 0;
		text4bp.x = -2 * rem;
		text4bp.y = 35.842 * rem;
		text4bp.scaleX = canvas_scale;
		text4bp.scaleY = canvas_scale;
		part3.addChild(text4bp);
		stage.update();
	};
	var text5 = new Image()
	text5.crossOrigin = 'anonymous';
	text5.src = "http://o.cztvcloud.com/181/4838001/images/text5.png";
	text5.onload = function (ev){
		var text5bp = new createjs.Bitmap(text5.src);
		text5bp.name = "text5bp";
		text5bp.alpha = 0;
		text5bp.x = 5 * rem;
		text5bp.y = 40.98 * rem;
		text5bp.scaleX = canvas_scale;
		text5bp.scaleY = canvas_scale;
		part3.addChild(text5bp);
		stage.update();
	};
	var p31 = new Image()
	p31.crossOrigin = 'anonymous';
	p31.src = "http://o.cztvcloud.com/181/4838001/images/p31.png";
	p31.onload = function (ev){
		var p31bp = new createjs.Bitmap(p31.src);
		p31bp.name = "p31bp";
		p31bp.alpha = 0;
		p31bp.x = 3 * rem;
		p31bp.y = 40.55 * rem;
		p31bp.scaleX = canvas_scale;
		p31bp.scaleY = canvas_scale;
		part3.addChild(p31bp);
		stage.update();
	};
	var p32 = new Image()
	p32.crossOrigin = 'anonymous';
	p32.src = "http://o.cztvcloud.com/181/4838001/images/p32.png";
	p32.onload = function (ev){
		var p32bp = new createjs.Bitmap(p32.src);
		p32bp.name = "p32bp";
		p32bp.alpha = 0;
		p32bp.x = -3 * rem;
		p32bp.y = 40.55 * rem;
		p32bp.scaleX = canvas_scale;
		p32bp.scaleY = canvas_scale;
		part3.addChild(p32bp);
		part3.addEventListener('click', function (){
			console.log('第二个老头, video1')
			videoplay(2)
		})
		stage.update();
	};
	var p33 = new Image()
	p33.crossOrigin = 'anonymous';
	p33.src = "http://o.cztvcloud.com/181/4838001/images/p33.png";
	p33.onload = function (ev){
		var p33bp = new createjs.Bitmap(p33.src);
		p33bp.name = "p33bp";
		p33bp.alpha = 0;
		p33bp.x = 1 * rem;
		p33bp.y = 40.55 * rem;
		p33bp.scaleX = canvas_scale;
		p33bp.scaleY = canvas_scale;
		part3.addChild(p33bp);
		stage.update();
	};
	//part4
	var part4 = new createjs.Container();
	stage.addChild(part4);
	var p41 = new Image()
	p41.crossOrigin = 'anonymous';
	p41.src = "http://o.cztvcloud.com/181/4838001/images/p41.png";
	p41.onload = function (ev){
		var p41bp = new createjs.Bitmap(p41.src);
		p41bp.name = "p41bp";
		p41bp.alpha = 0;
		p41bp.x = -2 * rem;
		p41bp.y = 55.58 * rem;
		p41bp.scaleX = canvas_scale;
		p41bp.scaleY = canvas_scale;
		part4.addChild(p41bp);
		stage.update();
	};
	var p42 = new Image()
	p42.crossOrigin = 'anonymous';
	p42.src = "http://o.cztvcloud.com/181/4838001/images/p42.png";
	p42.onload = function (ev){
		var p42bp = new createjs.Bitmap(p42.src);
		p42bp.name = "p42bp";
		p42bp.alpha = 0;
		p42bp.x = 2 * rem;
		p42bp.y = 55.58 * rem;
		p42bp.scaleX = canvas_scale;
		p42bp.scaleY = canvas_scale;
		part4.addChild(p42bp);
		stage.update();
		p42bp.addEventListener('click', function (){
			console.log('消防队员, video3')
			videoplay(3)
		})
	};
	var p43 = new Image()
	p43.crossOrigin = 'anonymous';
	p43.src = "http://o.cztvcloud.com/181/4838001/images/p43.png";
	p43.onload = function (ev){
		var p43bp = new createjs.Bitmap(p43.src);
		p43bp.name = "p43bp";
		p43bp.alpha = 0;
		p43bp.x = 0;
		p43bp.y = 58.5 * rem;
		p43bp.scaleX = canvas_scale;
		p43bp.scaleY = canvas_scale;
		part4.addChild(p43bp);
		stage.update();
	};
	/*
		 part5
	*/
	var part5 = new createjs.Container();
	stage.addChild(part5);
	var p51 = new Image()
	p51.crossOrigin = 'anonymous';
	p51.src = "http://o.cztvcloud.com/181/4838001/images/p51.png";
	p51.onload = function (ev){
		var p51bp = new createjs.Bitmap(p51.src);
		p51bp.name = "p51bp";
		p51bp.alpha = 0;
		p51bp.x = 1 * rem;
		p51bp.y = 70.50 * rem;
		p51bp.scaleX = canvas_scale;
		p51bp.scaleY = canvas_scale;
		part5.addChild(p51bp);
		stage.update();
	};
	var p52 = new Image()
	p52.crossOrigin = 'anonymous';
	p52.src = "http://o.cztvcloud.com/181/4838001/images/p52.png";
	p52.onload = function (ev){
		var p52bp = new createjs.Bitmap(p52.src);
		p52bp.name = "p52bp";
		p52bp.alpha = 0;
		p52bp.x = 4 * rem;
		p52bp.y = 70.50 * rem;
		p52bp.scaleX = canvas_scale;
		p52bp.scaleY = canvas_scale;
		part5.addChild(p52bp);
		stage.update();
		p52bp.addEventListener('click', function (){
			console.log('第四个老大爷, video3')
			videoplay(4)
		})
	};
	var p53 = new Image()
	p53.crossOrigin = 'anonymous';
	p53.src = "http://o.cztvcloud.com/181/4838001/images/p53.png";
	p53.onload = function (ev){
		var p53bp = new createjs.Bitmap(p53.src);
		p53bp.name = "p53bp";
		p53bp.alpha = 0;
		p53bp.x = 0.16 * rem;
		p53bp.y = 72.40 * rem;
		p53bp.scaleX = canvas_scale;
		p53bp.scaleY = canvas_scale;
		part5.addChild(p53bp);
		stage.update();
	};
	var p5text1 = new Image()
	p5text1.crossOrigin = 'anonymous';
	p5text1.src = "http://o.cztvcloud.com/181/4838001/images/p5text1.png";
	p5text1.onload = function (ev){
		var p5text1bp = new createjs.Bitmap(p5text1.src);
		p5text1bp.name = "p5text1bp";
		p5text1bp.alpha = 0;
		p5text1bp.x = 2.53 * rem;
		p5text1bp.y = 74.48 * rem;
		p5text1bp.scaleX = canvas_scale;
		p5text1bp.scaleY = canvas_scale;
		part5.addChild(p5text1bp);
		stage.update();
	};
	/*
		part6
	*/
	var part6 = new createjs.Container();
	stage.addChild(part6);
	var p6t1 = new Image()
	p6t1.crossOrigin = 'anonymous';
	p6t1.src = "http://o.cztvcloud.com/181/4838001/images/p6t1.png";
	p6t1.onload = function (ev){
		var p6t1bp = new createjs.Bitmap(p6t1.src);
		p6t1bp.name = "p6t1bp";
		p6t1bp.alpha = 0;
		p6t1bp.x = 0;
		p6t1bp.y = 81 * rem;
		p6t1bp.scaleX = canvas_scale;
		p6t1bp.scaleY = canvas_scale;
		part6.addChild(p6t1bp);
		stage.update();
	};
	var p6t2 = new Image()
	p6t2.crossOrigin = 'anonymous';
	p6t2.src = "http://o.cztvcloud.com/181/4838001/images/p6t2.png";
	p6t2.onload = function (ev){
		var p6t2bp = new createjs.Bitmap(p6t2.src);
		p6t2bp.name = "p6t2bp";
		p6t2bp.alpha = 0;
		p6t2bp.x = 0;
		p6t2bp.y = 81 * rem;
		p6t2bp.scaleX = canvas_scale;
		p6t2bp.scaleY = canvas_scale;
		part6.addChild(p6t2bp);
		stage.update();
	};
	var p6t3 = new Image()
	p6t3.crossOrigin = 'anonymous';
	p6t3.src = "http://o.cztvcloud.com/181/4838001/images/p6t3.png";
	p6t3.onload = function (ev){
		var p6t3bp = new createjs.Bitmap(p6t3.src);
		p6t3bp.name = "p6t3bp";
		p6t3bp.alpha = 0;
		p6t3bp.x = 0;
		p6t3bp.y = 81 * rem;
		p6t3bp.scaleX = canvas_scale;
		p6t3bp.scaleY = canvas_scale;
		part6.addChild(p6t3bp);
		stage.update();
	};
	var p6t4 = new Image()
	p6t4.crossOrigin = 'anonymous';
	p6t4.src = "http://o.cztvcloud.com/181/4838001/images/p6t4.png";
	p6t4.onload = function (ev){
		var p6t4bp = new createjs.Bitmap(p6t4.src);
		p6t4bp.name = "p6t4bp";
		p6t4bp.alpha = 1;
		p6t4bp.x = 0;
		p6t4bp.y = 83.44 * rem;
		p6t4bp.scaleX = canvas_scale;
		p6t4bp.scaleY = canvas_scale;
		part6.addChild(p6t4bp);
		stage.update();
	};
	var p6t5 = new createjs.Container();
	stage.addChild(p6t5);
	var p6t5 = new Image()
	p6t5.crossOrigin = 'anonymous';
	p6t5.src = "http://o.cztvcloud.com/181/4838001/images/p6t5.png";
	p6t5.onload = function (ev){
		var p6t5bp = new createjs.Bitmap(p6t5.src);
		p6t5bp.name = "p6t5bp";
		p6t5bp.alpha = 1;
		p6t5bp.x = 0;
		p6t5bp.y = 87.30 * rem;
		p6t5bp.scaleX = canvas_scale;
		p6t5bp.scaleY = canvas_scale;
		part6.addChild(p6t5bp);
		stage.update();
	};
	var p6t6 = new Image()
	p6t6.crossOrigin = 'anonymous';
	p6t6.src = "http://o.cztvcloud.com/181/4838001/images/p6t6.png";
	p6t6.onload = function (ev){
		var p6t6bp = new createjs.Bitmap(p6t6.src);
		p6t6bp.name = "p6t6bp";
		p6t6bp.alpha = 1;
		p6t6bp.x = 0;
		p6t6bp.y = 90.75 * rem;
		p6t6bp.scaleX = canvas_scale;
		p6t6bp.scaleY = canvas_scale;
		part6.addChild(p6t6bp);
		stage.update();
	};
	var p6t7 = new Image()
	p6t7.crossOrigin = 'anonymous';
	p6t7.src = "http://o.cztvcloud.com/181/4838001/images/p6t7.png";
	p6t7.onload = function (ev){
		var p6t7bp = new createjs.Bitmap(p6t7.src);
		p6t7bp.name = "p6t7bp";
		p6t7bp.alpha = 0;
		p6t7bp.x = 0;
		p6t7bp.y = 96 * rem;
		p6t7bp.scaleX = canvas_scale;
		p6t7bp.scaleY = canvas_scale;
		part6.addChild(p6t7bp);
		stage.update();
	};
	//part6gif1
	var part6gif1 = {//创建一个动画实例
		"images": ["http://o.cztvcloud.com/181/4838001/images/gif-1.png"],
		"frames": {
			"width": 400,            //每个图的高度为292，宽度为165，一共有64张图
			"height": 320,
			"count": 5
		},
		"animations": {
			"start": [0, 4, 'start', 0.01],
		}
	}
	var sppart6gif1 = new createjs.SpriteSheet(part6gif1);
	var am_p6_gif1 = new createjs.Sprite(sppart6gif1);
	am_p6_gif1.gotoAndPlay("start");
	am_p6_gif1.x = 3.2 * rem;
	am_p6_gif1.y = 87.34 * rem;
	am_p6_gif1.scaleX = canvas_scale;
	am_p6_gif1.scaleY = canvas_scale;
	part6.addChild(am_p6_gif1)
	stage.update()
	//part6gif2
	var part6gif3 = {//创建一个动画实例
		"images": ["http://o.cztvcloud.com/181/4838001/images/gif-3.png"],
		"frames": {
			"width": 474,             //每个图的高度为292，宽度为165，一共有64张图
			"height": 303,
			"count": 19
		},
		"animations": {
			start: {
				frames: [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 15, 16, 17, 18],
				next: "stop",
				speed: 0.08
			},
			stop: {
				frames: [18],
				next: "start",
				speed: 0.08
			},
		}
	}
	var sppart6gif3 = new createjs.SpriteSheet(part6gif3);
	var am_p6_gif3 = new createjs.Sprite(sppart6gif3);
	am_p6_gif3.gotoAndPlay("start");
	am_p6_gif3.x = -0.5 * rem;
	am_p6_gif3.y = 83.44 * rem;
	am_p6_gif3.scaleX = canvas_scale;
	am_p6_gif3.scaleY = canvas_scale;
	part6.addChild(am_p6_gif3)
	stage.update()
	//part6gif3
	var part6gif3 = {//创建一个动画实例
		"images": ["http://o.cztvcloud.com/181/4838001/images/gif2.png"],
		"frames": {
			"width": 474,            //每个图的高度为292，宽度为165，一共有64张图
			"height": 303,
			"count": 19,
		},
		"animations": {
			start: {
				frames: [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 15, 16, 17, 18],
				next: "stop",
				speed: 0.08
			},
			stop: {
				frames: [18],
				next: "start",
				speed: 0.08
			},
		}
	}
	var sppart6gif2 = new createjs.SpriteSheet(part6gif3);
	var am_p6_gif2 = new createjs.Sprite(sppart6gif2);
	am_p6_gif2.gotoAndPlay("start");
	am_p6_gif2.x = -0.5 * rem;
	am_p6_gif2.y = 90.44 * rem;
	am_p6_gif2.scaleX = canvas_scale;
	am_p6_gif2.scaleY = canvas_scale;
	part6.addChild(am_p6_gif2)
	stage.update()
	//tea2
	var tea2sp = {//创建一个动画实例
		"images": ["http://o.cztvcloud.com/181/4838001/images/test.png"],
		"frames": {
			"width": 270,            //每个图的高度为292，宽度为165，一共有64张图
			"height": 214,
			"count": 18
		},
		"animations": {
			start: {
				frames: [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 15, 16, 17],
				next: "stop",
				speed: 0.25
			},
			stop: {
				frames: [17],
				next: "stop",
				speed: 1
			},
			// "start": [0, 0, 'run', 0.1],
			// "run": [0, 18],                  //0帧到25帧是跳
		}
	}
	var spriteSheet2 = new createjs.SpriteSheet(tea2sp);
	var am_sp2 = new createjs.Sprite(spriteSheet2);
	am_sp2.gotoAndPlay("stop");
	am_sp2.scale = canvas_scale
	am_sp2.x = 3.0 * rem;
	am_sp2.y = 101.35 * rem;
	var texted = false
	am_sp2.addEventListener('click', function (){
		am_sp2.gotoAndPlay('start')
		//添加文字
		if (!texted) {
			var size = 0.47 * rem + 'px blod 宋体';
			var txt = new createjs.Text("", size, "#b9361e");
			txt.name = 'zhuli',
				txt.alpha = 0,
				txt.x = 4.6 * rem;                   //改变txt  X的坐标（在canvas中距离 左侧 的坐标）
			txt.y = 100 * rem;                   //改变txt  Y的坐标（在canvas中距离 顶部 的坐标）
			txt.text = "你是第" + num + "位助力者";           		  //改变txt的文本内容
			txt.textAlign = "center";   		  //水平居中
			txt.textBaseline = "middle";		  //垂直居中
			part6.addChild(txt);                  //完成之后需要添加到stage中才能正常显示
			createjs.Tween.get(part6.getChildByName("zhuli")).to({
				alpha: 1,
				x: 2.6 * rem
			}, 300)
			stage.update();                       //调用updata更新
			texted = true
		}
	})
	part6.addChild(am_sp2)
	/*
	*  part7
	*/
	var part7 = new createjs.Container();
	stage.addChild(part7);
	var p7 = new Image()
	p7.crossOrigin = 'anonymous';
	p7.src = "http://o.cztvcloud.com/181/4838001/images/p7.png";
	p7.onload = function (ev){
		var p7bp = new createjs.Bitmap(p7.src);
		p7bp.name = "p7bp";
		p7bp.alpha = 0;
		p7bp.x = 0 * rem;
		p7bp.y = 106.5 * rem;
		p7bp.scaleX = canvas_scale;
		p7bp.scaleY = canvas_scale;
		part7.addChild(p7bp);
		stage.update();
	};
	var fxbtn = new Image()
	fxbtn.crossOrigin = 'anonymous';
	fxbtn.src = "http://o.cztvcloud.com/181/4838001/images/fxbtn.jpg";
	fxbtn.onload = function (ev){
		var fxbtnbp = new createjs.Bitmap(fxbtn.src);
		fxbtnbp.name = "fxbtnbp";
		fxbtnbp.alpha = 0;
		fxbtnbp.x = 3.195 * rem;
		fxbtnbp.y = 110.06 * rem;
		fxbtnbp.scaleX = canvas_scale;
		fxbtnbp.scaleY = canvas_scale;
		part7.addChild(fxbtnbp);
		fxbtnbp.addEventListener('click', function (){
			$('.sharebox').fadeIn()
		})
		stage.update();
	};
	var logo = new Image()
	logo.crossOrigin = 'anonymous';
	logo.src = "http://o.cztvcloud.com/181/4838001/images/logo.png";
	logo.onload = function (ev){
		var logobp = new createjs.Bitmap(logo.src);
		logobp.name = "logobp";
		logobp.alpha = 0;
		logobp.x = 2.665 * rem;
		logobp.y = 111.5 * rem;
		logobp.scaleX = canvas_scale;
		logobp.scaleY = canvas_scale;
		part7.addChild(logobp);
		stage.update();
	};
	//红日亭手势
	var hrimagehand = new Image()
	hrimagehand.crossOrigin = 'anonymous';
	hrimagehand.src = "http://o.cztvcloud.com/181/4838001/images/hand.png";
	hrimagehand.onload = function (ev){
		var hrimagehandbp = new createjs.Bitmap(hrimagehand.src);
		hrimagehandbp.name = "handhr"
		hrimagehandbp.x = 5 * rem;
		hrimagehandbp.y = 72.5 * rem;
		hrimagehandbp.scaleX = canvas_scale;
		hrimagehandbp.scaleY = canvas_scale;
		part7.addChild(hrimagehandbp);
		createjs.Tween.get(part7.getChildByName("handhr"), {loop: true}).to({
			alpha: 0.2,
		}, 300).to({
			alpha: 1,
		}, 300)
		stage.update();
	};
	//最后的手势
	var imagehand = new Image()
	imagehand.crossOrigin = 'anonymous';
	imagehand.src = "http://o.cztvcloud.com/181/4838001/images/hand.png";
	imagehand.onload = function (ev){
		var imagehandbp = new createjs.Bitmap(imagehand.src);
		imagehandbp.name = "hand2"
		imagehandbp.x = 5 * rem;
		imagehandbp.y = 102.5 * rem;
		imagehandbp.scaleX = canvas_scale;
		imagehandbp.scaleY = canvas_scale;
		part7.addChild(imagehandbp);
		createjs.Tween.get(part7.getChildByName("hand2"), {loop: true}).to({
			alpha: 0.2,
		}, 300).to({
			alpha: 1,
		}, 300)
		stage.update();
	};
	/*
	*事件监听
	*事件监听
	*事件监听
	*/
	var slide = 0;
	var kadian1 = [-Math.floor(12 * rem), true, -18 * rem]
	var kadian2 = [-Math.floor(14 * rem), true, -18 * rem]
	var kadian3 = [-Math.floor(32 * rem), true, -38 * rem]
	var kadian4 = [-Math.floor(52 * rem), true, -58 * rem]
	var kadian5 = [-Math.floor(65.5 * rem), true, -70 * rem]
	var kadian6 = [-Math.floor(70.5 * rem), true, -77 * rem]
	var kadian7 = [-Math.floor(90.5 * rem), true, -94 * rem]
	var kadian8 = [-Math.floor(95 * rem), true, -110 * rem]
	function scroll(){
		// console.log(tempy, kadian1[0]);
		if (kadian1[1]) {
			if ((tempy < kadian1[0]) && (tempy > kadian1[2])) {
				kadian1[1] = false;
				createjs.Tween.get(mrgu.getChildByName("mrgutext")).to({
					alpha: 1,
					x: 3.41 * rem,
				}, 450, createjs.Ease.quadOut);
			}
		}
		else if (kadian2[1]) {
			if ((tempy < kadian2[0]) && (tempy > kadian2[2])) {
				kadian2[1] = false;
				createjs.Tween.get(mrgu.getChildByName("guchalu")).to({
					alpha: 1,
					x: 0,
				}, 450)
				createjs.Tween.get(mrgu.getChildByName("chalutextbp")).wait(500).to({
					alpha: 1,
					x: 0,
				}, 450)
			}
		}
		else if (kadian3[1]) {
			if ((tempy < kadian3[0]) && (tempy > kadian3[2])) {
				kadian3[1] = false;
				createjs.Tween.get(part3.getChildByName("text4bp")).to({
					alpha: 1,
					x: 0,
				}, 450)
				createjs.Tween.get(part3.getChildByName("text5bp")).wait(1000).to({
					alpha: 1,
					x: 3.42 * rem,
				}, 450)
				createjs.Tween.get(part3.getChildByName("p31bp")).wait(1000).to({
					alpha: 1,
					x: 0,
				}, 450)
				createjs.Tween.get(part3.getChildByName("p32bp")).wait(1400).to({
					alpha: 1,
					x: 0
				}, 450)
				createjs.Tween.get(part3.getChildByName("p33bp")).wait(1300).to({
					alpha: 1,
					x: 0,
				}, 450)
			}
		}
		else if (kadian4[1]) {
			if ((tempy < kadian4[0]) && (tempy > kadian4[2])) {
				kadian4[1] = false;
				createjs.Tween.get(part4.getChildByName("p41bp")).to({
					alpha: 1,
					x: 0,
				}, 450)
				createjs.Tween.get(part4.getChildByName("p42bp")).to({
					alpha: 1,
					x: 0,
				}, 450)
				createjs.Tween.get(part4.getChildByName("p43bp")).wait(1000).to({
					alpha: 1,
					x: 0,
					y: 59.4 * rem,
				}, 450)
			}
		} else if (kadian5[1]) {
			if ((tempy < kadian5[0]) && (tempy > kadian5[2])) {
				kadian5[1] = false;
				createjs.Tween.get(part5.getChildByName("p51bp")).to({
					alpha: 1,
					x: 2.95 * rem,
				}, 450)
				createjs.Tween.get(part5.getChildByName("p52bp")).to({
					alpha: 1,
					x: 2.95 * rem,
				}, 450)
				createjs.Tween.get(part5.getChildByName("p53bp")).wait(1000).to({
					alpha: 1,
					x: 1.16 * rem
				}, 450)
				createjs.Tween.get(part5.getChildByName("p5text1bp")).wait(1000).to({
					alpha: 1,
				}, 450)
			}
		} else if (kadian6[1]) {
			if ((tempy < kadian6[0]) && (tempy > kadian6[2])) {
				kadian6[1] = false;
				createjs.Tween.get(part6.getChildByName("p6t1bp")).to({
					alpha: 1,
					y: 79.87 * rem,
				}, 450, createjs.Ease.quadOut);
				createjs.Tween.get(part6.getChildByName("p6t2bp")).wait(200).to({
					alpha: 1,
					y: 79.87 * rem,
				}, 450, createjs.Ease.quadOut);
				createjs.Tween.get(part6.getChildByName("p6t3bp")).wait(400).to({
					alpha: 1,
					y: 79.87 * rem,
				}, 450, createjs.Ease.quadOut);
			}
		} else if (kadian7[1]) {
			if ((tempy < kadian7[0]) && (tempy > kadian7[2])) {
				kadian7[1] = false;
				createjs.Tween.get(part6.getChildByName("p6t7bp")).to({
					alpha: 1,
					y: 94.86 * rem,
				}, 450, createjs.Ease.quadOut);
			}
		} else if (kadian8[1]) {
			if ((tempy < kadian8[0]) && (tempy > kadian8[2])) {
				kadian8[1] = false;
				createjs.Tween.get(part7.getChildByName("p7bp")).to({
					alpha: 1,
					y: 105.55 * rem,
				}, 600, createjs.Ease.quadOut);
				createjs.Tween.get(part7.getChildByName("fxbtnbp")).to({
					alpha: 1,
					y: 109.06 * rem,
				}, 450, createjs.Ease.quadOut);
				createjs.Tween.get(part7.getChildByName("logobp")).to({
					alpha: 1,
					y: 110.5 * rem,
				}, 450, createjs.Ease.quadOut);
			}
		}
	}
	// stage.scaleX = window.innerWidth / 750;
	// stage.scaleY = window.innerWidth / 750;
})
var videolists = [
	'http://v3.cztv.com/cztv/vod/2018/07/14/21b6ad0fe99646d4aad6ca7fc16d3688/h264_1500k_mp4.mp4',
	'http://v3.cztv.com/cztv/vod/2018/08/17/2d978b5d0d1b4d7fa2563e8d0e1b899e/9a0741062f2f44e583b9d53d972ad35b_H264_1500K_MP4.mp4',
	'http://v3.cztv.com/cztv/vod/2018/08/17/4ceb1eaf653a40b599afe6242894040a/c0ab43b76b6243cca9293471be9023fb_H264_1500K_MP4.mp4',
	'http://v3.cztv.com/cztv/vod/2018/08/16/74b2711ea4334f58bc5212f05e953eb7/4446cb336f1d49dd986554f3c3cc4706_H264_1500K_MP4.mp4',
]
var num = 0
//点击量
$.ajax({
	url: 'http://d.cztvcloud.com/media/news?data_id=4838001&terminal=web&channel_id=181', /*url     :'http://d.cztvcloud.com/media/news?data_id=764588&terminal=web&channel_id=192',*/
	type: 'get',
	dataType: 'jsonp',
	success: function (rlt){
		var hints = rlt.data.hits
		num = 2 * parseInt(hints)
		var analysisurl = "http://d.cztvcloud.com/visit/ie";
		var channelId = '181';
		var itemId = '4838001';
		var title = 'read';
		var editorId = '';
		var type = '';
		analysis(analysisurl, channelId, itemId, title, editorId, 1, type);
		function analysis(url, channelId, itemId, title, editorId, terminal, type){
			var data = {
				channel_id: channelId,
				item_id: itemId,
				title: title,
				editor_id: editorId,
				terminal: terminal,
				type: type
			}
			$.ajax({
				type: "GET", url: url, data: data, dataType: "jsonp", success: function (data){
					console.log(data);
				}
			});
		}
	}
})
function init(){
	if (IsPC()) {
		var height = window.innerHeight
		var width = height * 414 / 799
		console.log(width, height);
		w = 414;
		h = 666;
		// w = width;
		// h = height;
		var pcw = 750 * (w / 750);//rem
		var pch = 1334 * (w / 750);//
		$("html").css({
			'width': w,
			'margin': "0 auto",
			'marginTop': '0',
			"height": h,
			"background": "#fff"
		});
		$('.main').css({'top': '-1rem'})
		$("html").css({fontSize: w / 750 * 100 + "px"});
		$("html").css({minHeight: h});
	} else {
		var w = $(window).width();
		var h = $(window).height();
		$("html").css({fontSize: w / 750 * 100});
		$("body").height(h);
		$('#swiper-container').height(h)
	}
	function IsPC(){
		var userAgentInfo = navigator.userAgent;
		var Agents = new Array("Android", "iPhone", "SymbianOS", "Windows Phone", "iPod");
		var flag = true;
		for (var v = 0; v < Agents.length; v++) {
			if (userAgentInfo.indexOf(Agents[v]) > 0) {
				flag = false;
				break;
			}
		}
		return flag;
	}
	function GetQueryString(name){
		var reg = new RegExp("(^|&)" + name + "=([^&]*)(&|$)");
		var r = window.location.search.substr(1).match(reg);
		if (r != null) return unescape(r[2]);
		return null;
	}
}
function IsPC(){
	var userAgentInfo = navigator.userAgent;
	var Agents = new Array("Android", "iPhone", "SymbianOS", "Windows Phone", "iPad", "iPod");
	var flag = true;
	for (var v = 0; v < Agents.length; v++) {
		if (userAgentInfo.indexOf(Agents[v]) > 0) {
			flag = false;
			break;
		}
	}
	return flag;
}
function GetQueryString(name){
	var reg = new RegExp("(^|&)" + name + "=([^&]*)(&|$)");
	var r = window.location.search.substr(1).match(reg);
	if (r != null) return unescape(r[2]);
	return null;
}
function orient(){
	if (window.orientation == 0 || window.orientation == 180) {//竖屏;//ipad、iphone竖屏；Andriod横屏
		$('.loading').hide().removeClass('hp');
		return false;
	} else if (window.orientation == 90 || window.orientation == -90) {//横屏;//ipad、iphone横屏；Andriod竖屏
		$('.loading').show().addClass('hp');
		var video = document.getElementById('video');
		video.ended();
		video.addEventListener('ended', function (){
			$('#video,.mask').hide()
		})
		$('#video').hide()
		return false;
	} else {
		$(".loading").fadeOut();
	}
}
function isAndroid(){
	var u = navigator.userAgent;
	var isAndroid = u.indexOf('Android') > -1 || u.indexOf('Adr') > -1; //android终端
	return isAndroid
}


